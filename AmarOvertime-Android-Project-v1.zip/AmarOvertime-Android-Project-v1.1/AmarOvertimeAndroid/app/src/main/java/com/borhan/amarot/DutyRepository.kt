package com.borhan.amarot.repository

import com.borhan.amarot.data.DutyDao
import com.borhan.amarot.data.DutyRecord
import kotlinx.coroutines.flow.Flow

class DutyRepository(private val dutyDao: DutyDao) {

    suspend fun saveDuty(dutyRecord: DutyRecord) {
        dutyDao.insertDuty(dutyRecord)
    }

    fun getMonthlyOtHours(monthYear: String): Flow<Double?> {
        return dutyDao.getTotalMonthlyOtHours(monthYear)
    }

    fun getMonthlyRegularHours(monthYear: String): Flow<Double?> {
        return dutyDao.getTotalMonthlyRegularHours(monthYear)
    }

    fun getMonthlyOtWage(monthYear: String): Flow<Double?> {
        return dutyDao.getTotalMonthlyOtWage(monthYear)
    }

    fun getMonthlyRecords(monthYear: String): Flow<List<DutyRecord>> {
        return dutyDao.getDutiesForMonth(monthYear)
    }
}
