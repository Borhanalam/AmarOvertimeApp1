package com.borhan.amarot.util

import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.Duration
import java.util.Locale

enum class ShiftType {
    DAY, NIGHT
}

data class CalculationResult(
    val totalHours: Double,
    val regularHours: Double,
    val otHours: Double
)

object OvertimeCalculator {

    private val timeFormatter = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH)

    /**
     * Midnight-safe OT calculation.
     * Example: DAY 08:00 AM -> 12:30 AM = 7.50 OT hours.
     */
    fun calculate(
        startDateStr: String,
        startTimeStr: String,
        endDateStr: String,
        endTimeStr: String,
        shiftType: ShiftType
    ): CalculationResult {

        val startLocalTime = LocalTime.parse(startTimeStr.uppercase(), timeFormatter)
        val endLocalTime = LocalTime.parse(endTimeStr.uppercase(), timeFormatter)

        val startDateTime = LocalDateTime.parse("${startDateStr}T$startLocalTime")
        var endDateTime = LocalDateTime.parse("${endDateStr}T$endLocalTime")

        if (!endDateTime.isAfter(startDateTime)) {
            endDateTime = endDateTime.plusDays(1)
        }

        val totalMinutes = Duration.between(startDateTime, endDateTime).toMinutes().coerceAtLeast(0)
        val totalHours = totalMinutes / 60.0

        val otCutoffTime = if (shiftType == ShiftType.DAY) {
            LocalTime.of(17, 0)
        } else {
            LocalTime.of(4, 0)
        }

        var otCutoffDateTime = startDateTime.toLocalDate().atTime(otCutoffTime)

        if (shiftType == ShiftType.NIGHT && !otCutoffDateTime.isAfter(startDateTime)) {
            otCutoffDateTime = otCutoffDateTime.plusDays(1)
        } else if (shiftType == ShiftType.DAY && startDateTime.toLocalTime().isAfter(otCutoffTime)) {
            otCutoffDateTime = startDateTime
        }

        val otMinutes = if (endDateTime.isAfter(otCutoffDateTime)) {
            Duration.between(
                if (startDateTime.isAfter(otCutoffDateTime)) startDateTime else otCutoffDateTime,
                endDateTime
            ).toMinutes().coerceAtLeast(0)
        } else {
            0L
        }

        val otHours = otMinutes / 60.0
        val regularHours = if (shiftType == ShiftType.DAY) {
            // 1 hour lunch deduction for day duty.
            (totalHours - 1.0 - otHours).coerceAtLeast(0.0).coerceAtMost(8.0)
        } else {
            (totalHours - otHours).coerceAtLeast(0.0).coerceAtMost(8.0)
        }

        return CalculationResult(
            totalHours = String.format(Locale.ENGLISH, "%.2f", totalHours).toDouble(),
            regularHours = String.format(Locale.ENGLISH, "%.2f", regularHours).toDouble(),
            otHours = String.format(Locale.ENGLISH, "%.2f", otHours).toDouble()
        )
    }
}
