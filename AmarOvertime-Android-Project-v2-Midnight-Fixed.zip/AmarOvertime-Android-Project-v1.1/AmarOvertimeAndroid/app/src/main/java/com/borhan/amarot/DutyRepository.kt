package com.borhan.amarot.util

import java.time.LocalDateTime
import java.time.LocalTime
import java.time.Duration
import java.util.Locale

object OvertimeCalculator {

    /**
     * ইন/আউট টাইম অনুসারে OT হিসাব করে।
     * Out Time রাত ১২টার পরে হলে সেটিকে পরের দিনের সময় হিসেবে ধরা হয়।
     */
    fun calculateOtHours(
        startDateTime: LocalDateTime,
        endDateTime: LocalDateTime,
        isNightShift: Boolean = false
    ): Double {
        var adjustedEnd = endDateTime
        if (!adjustedEnd.isAfter(startDateTime)) {
            adjustedEnd = adjustedEnd.plusDays(1)
        }

        val thresholdTime = if (isNightShift) LocalTime.of(4, 0) else LocalTime.of(17, 0)
        var threshold = startDateTime.toLocalDate().atTime(thresholdTime)

        if (isNightShift) {
            // Night OT starts at 04:00 on the next calendar day.
            if (!threshold.isAfter(startDateTime)) threshold = threshold.plusDays(1)
        } else if (startDateTime.toLocalTime().isAfter(thresholdTime)) {
            // If a day shift starts after 17:00, OT starts from actual In Time.
            threshold = startDateTime
        }

        if (!adjustedEnd.isAfter(threshold)) return 0.0

        val otMinutes = Duration.between(threshold, adjustedEnd).toMinutes().coerceAtLeast(0)
        return String.format(Locale.ENGLISH, "%.2f", otMinutes / 60.0).toDouble()
    }
}
