package com.borhan.amarot.util

import java.time.LocalDateTime
import java.time.LocalTime
import java.time.Duration

object OvertimeCalculator {

    /**
     * ইন এবং আউট টাইম অনুসারে ওটি (OT) হিসাব করার ফাংশন।
     * রাত ১২টা অতিক্রম করলেও সঠিকভাবে ঘণ্টা হিসাব করবে।
     */
    fun calculateOtHours(
        startDateTime: LocalDateTime,
        endDateTime: LocalDateTime,
        isNightShift: Boolean = false
    ): Double {
        // যদি আউটের সময় ইন এর চেয়ে আগের হয় (যা হওয়া সম্ভব নয়), তবে আউট টাইম পরদিনের ধরে নেওয়া
        var adjustedEndDateTime = endDateTime
        if (adjustedEndDateTime.isBefore(startDateTime)) {
            adjustedEndDateTime = adjustedEndDateTime.plusDays(1)
        }

        // থ্রেশহোল্ড টাইম নির্ধারণ (ডে শিফটের জন্য বিকাল ১৭:০০ / ৫:০০ PM, নাইট শিফটের জন্য ভোর ৪:০০ AM)
        val thresholdTime = if (isNightShift) LocalTime.of(4, 0) else LocalTime.of(17, 0)

        // থ্রেশহোল্ড শুরুর তারিখ ও সময়
        var thresholdStartDateTime = LocalDateTime.of(startDateTime.toLocalDate(), thresholdTime)

        // ডে শিফটে যদি ইন টাইম বিকাল ৫টার পরে হয়, তবে ইন টাইম থেকেই ওটি গণনা হবে
        if (!isNightShift && startDateTime.toLocalTime().isAfter(thresholdTime)) {
            thresholdStartDateTime = startDateTime
        }

        // যদি আউটের সময় থ্রেশহোল্ড সময়ের আগে শেষ হয়ে যায়, তবে কোনো ওটি থাকবে না
        if (adjustedEndDateTime.isBefore(thresholdStartDateTime)) {
            return 0.0
        }

        // থ্রেশহোল্ড সময় থেকে আউটের সময় পর্যন্ত মিনিটের পার্থক্য বের করা
        val otMinutes = Duration.between(thresholdStartDateTime, adjustedEndDateTime).toMinutes()

        // মিনিটকে ঘণ্টায় রূপান্তর করা (কমপক্ষে ০ ধরে)
        val otHours = otMinutes / 60.0
        return if (otHours > 0) String.format("%.2f", otHours).toDouble() else 0.0
    }
}
